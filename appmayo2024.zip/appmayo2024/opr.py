
def sum(var1, var2):
    c=var1+var2
    return c

def res(var1, var2):
    c=var1-var2
    return c

def mul(var1, var2):
    c=var1*var2
    return c

def div(var1, var2):
    c=var1/var2
    return c
