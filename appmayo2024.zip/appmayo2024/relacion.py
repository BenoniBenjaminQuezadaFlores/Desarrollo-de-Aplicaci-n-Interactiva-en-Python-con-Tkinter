import opr
import datosus
def fnmate2():
    print("Este programa realiza operaciones de Relacion de Expresion con dos números")
    var1, var2 = datosus.datanum()

    print("a) Verifica si el primer numero es mayor que el segundo numero.")
    print("b) Verifica si el primer numero es menor que el segundo numero.")
    print("c) Verifica si los dos numero son iguales.")
    print("d) Verifica si los dos numeros son diferentes.")
    d3=input("dame una opción: ")
    match d3:
        case 'a':
            c = var1 > var2
            print(f"El resultado de la comparación es: {var1} > {var2} es {c}")
        case 'b':
            c= var1 < var2 
            print(f"El resultado de la comparación es: {var1} < {var2} es {c}")
        case 'c':
            c= var1 == var2 
            print(f"El resultado de la comparación es: {var1} == {var2} es {c}")
        case 'd':
            c= var1 != var2
            print(f"El resultado de la comparación es: {var1} != {var2} es {c}") 
        case _:
            print("La opción no es válida")

    print("\nGracias por usar este función (Relacion de expresiones)")
