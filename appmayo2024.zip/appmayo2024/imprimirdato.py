import datosus
def impr1():
    Name = []
    Edad = []
    Correo = []
    print("Este código adquiere datos de usuario y los imprime")
    g=int(float(input("¿Cuantos datos quieres ingresar: ")))

    for i in range (g):
        name1, age1, mail1=datosus.data1()
        Name.append(name1)
        Edad.append(age1)
        Correo.append(mail1)

    for i in range(g):
        print(f"El nombre del usuario {i}, es: {Name[i]} ")
        print(f"La edad del usuario {i}, es: {Edad[i]} ")
        print(f"El correo electrónico del usuario {i}, es: {Correo[i]} ")

    print("Gracias por usar esta función")