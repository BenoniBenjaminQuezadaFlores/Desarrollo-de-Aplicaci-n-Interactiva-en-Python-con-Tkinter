import os
import datetime
fechaactual = datetime.datetime.now()
def mkfile():
    var1 = float(input("Dame la temperatura a gaurdar: "))
    print(f"El valor de la temperatura es: {var1} {fechaactual}")

    file = open("C:/Python311/appmayo2024/temperatura.txt", "w")
    file.write(f"\nTemperatura: {var1} {fechaactual}\n")
    file.close()
    return 0

