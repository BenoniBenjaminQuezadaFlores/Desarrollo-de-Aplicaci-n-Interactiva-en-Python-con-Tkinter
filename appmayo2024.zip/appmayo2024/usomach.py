print("Este programa usa de manera básica match-case")

u='s'
while (u=='s'):
    print("1.- Imprime nombre")
    print("2- Imprime edad")
    print("3.- Imprime días")

    d1=input("dame una opción: ")
    match d1:
        case '1':
            name=input("Dame tu nombre: ")
            print(f"Tu nombre es: {name}")
        case '2':
            edad=input("Dame tu edad: ")
            print(f"Tu edad es: {edad}")
        case '3':
            dias=input("Dame cuantos días faltan para tu examen: ")
            print(f"Los días que falta para tu examen son: {dias}")
        case _:
            print("La opción no es válida")
    u=input("Deseas continuar(s/n): ")

print("\nGracias por usar este programa")