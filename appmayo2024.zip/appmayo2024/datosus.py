def datanum():
    var1=float(input("Dame el dato 1: "))
    var2=float(input("Dame el dato 2: "))
    return var1, var2

def data1():
    name1=input("Dame tu nombre: ")
    age1=float(input("Dame tu edad: "))
    age1=int(age1)
    mail1=input("Dame tu correo electronico: ")
    return name1, age1, mail1