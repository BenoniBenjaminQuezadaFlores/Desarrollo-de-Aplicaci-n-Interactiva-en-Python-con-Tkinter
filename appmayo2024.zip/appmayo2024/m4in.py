import mate
import imprimirdato
import archivo  
import relacion
d1='0'
u='s'
print("Este programa es una aplicación de todos los elementos de mi curso básico de python")


while (u=='s'):
    print("1.- Realiza operaciones matemáticas básicas")
    print("2.- Adquiere e imprime datos de contacto de usuario")
    print("3.- Adquiere un dato y lo guarda en un archivo de texto")
    print("4.- Realiza Operaciones matematicas de Relacion de Expresion")

    d1=input("dame una opción: ")
    match d1:
        case '1':
            mate.fnmate()
        case '2':
            imprimirdato.impr1()
        case '3':
            archivo.mkfile()
        case '4':
            relacion.fnmate2()
        case _:
            print("La opción no es válida")
    u=input("Deseas continuar(s/n): ")

print("\nGracias por usar este programa")