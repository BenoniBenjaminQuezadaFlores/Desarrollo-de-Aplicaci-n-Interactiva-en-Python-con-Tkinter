import opr
import datosus
def fnmate():
    print("Este programa realiza operaciones matemáticas con dos números")
    var1, var2 = datosus.datanum()

    print("a) Realiza la suma de dos números.")
    print("b) Realiza la resta de dos números.")
    print("c) Realiza la multiplicación de dos números.")
    print("d) Realiza la división de dos números.")
    d2=input("dame una opción: ")
    match d2:
        case 'a':
            c=opr.sum(var1, var2)
            print(f"El resultado de la suma es: {c}")
        case 'b':
            c=opr.res(var1, var2)
            print(f"El resultado de la rest es: {c}")
        case 'c':
            c=opr.mul(var1, var2)
            print(f"El resultado de la multiplicación es: {c}")
        case 'd':
            c=opr.div(var1, var2)
            print(f"El resultado de la división es: {c}") 
        case _:
            print("La opción no es válida")

    print("\nGracias por usar este función (mate)")
